#ifndef objectManager

#include <gl/glew.h>
#include <gl/freeglut.h>
#include <gl/freeglut_ext.h>
#include <glm/glm.hpp>
#include <glm/ext.hpp>
#include <glm/gtc/matrix_transform.hpp>
#include <random>
#include <time.h>

#define mapSize 20
#define CARDNUM 5
#define BOXSIZE 0.5

enum directionMode { STOP, FRONTUP, BACKUP, LEFTUP, RIGHTUP, FRONTDOWN, BACKDOWN, LEFTDOWN, RIGHTDOWN, FRONT, BACK, LEFT, RIGHT, FALL, STARTWARP, ENDWARP};

class objectManager { //ī�� Ȥ�� ������ ������Ʈ �ִϸ��̼��� ������ Ŭ����
	GLfloat objectRGB[3]{0.0f};
	GLfloat size = 0.5;
	int direction = STOP, x = 0, y = 0, z = 0, dis = 0, frame = 0;
	int WarpX = 0, WarpY = 0, WarpZ = 0;

	bool dead = false;
public:
	glm::mat4 transform = glm::mat4(1.0f);
	glm::mat4 Warptransform = glm::mat4(1.0f);

	objectManager();
	~objectManager(){}
	
	void rotateMatrix(GLfloat degree, int base);

	void translateMatrix(GLfloat x, GLfloat y, GLfloat z);

	void scaleMatrix(GLfloat rateX, GLfloat rateY, GLfloat rateZ);

	void changeDirection(int Mode, int Dis);

	void setHeight(int height);

	int getX();
	int getY();
	int getZ();

	bool checkDead();

	void die();

	void setZero();

	void returnPlace();

	void initPlayer(GLfloat BoxSize, int index);

	void move(int frontHeight, int backHeight, int frontfrontHeight, int backbackHeight, int currentHeight,	int* PlayerScore);

	void Warp(glm::mat4 location, int x , int y, int z);

	int getDirection();
};

class CardManager { //ī�� Ȥ�� ������ ������Ʈ �ִϸ��̼��� ������ Ŭ����
	int cardMove[CARDNUM]; //0(�������), 1, 2, 3, 4, 5(mapDown), 6(Object warp)
	int cardDirection[CARDNUM];
	bool WarpChance;

public:
	glm::mat4 transform[CARDNUM];
	bool DistroyMap;

	CardManager();
	~CardManager() = default;

	void cardInsert(int cardKind, int direction);
	void cardDelete(int index);

	void translateMatrix(int index, GLfloat x, GLfloat y, GLfloat z);
	int getCardMove(int index);
	int getcardDirection(int index);

	void UseWarp();

	bool GetWarp();
};



#endif
